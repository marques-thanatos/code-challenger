package com.example.code_challenger

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
